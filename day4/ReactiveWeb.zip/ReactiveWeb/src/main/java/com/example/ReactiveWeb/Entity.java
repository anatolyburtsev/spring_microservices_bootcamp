package com.example.ReactiveWeb;

public class Entity {

    public String name;

}
