package ru.java.mentor.storeoriginaldata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreoriginaldataApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreoriginaldataApplication.class, args);
	}

}

