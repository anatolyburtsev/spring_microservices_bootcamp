package ru.java.mentor.storeinvertedindex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreinvertedindexApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreinvertedindexApplication.class, args);
	}

}

